package com.example.footyapp.ui.myTeam;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.example.footyapp.ApiHandlerInterface;
import com.example.footyapp.R;
import com.example.footyapp.pojos.LeagueStanding;
import com.example.footyapp.pojos.Squad;
import com.example.footyapp.pojos.Table;
import com.example.footyapp.pojos.TeamSquad;
import com.example.footyapp.ui.League.LeagueTableAdapter;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MyTeamFragment extends Fragment {


    private ApiHandlerInterface apiHandlerInterface;
    private MyTeamViewModel myTeamViewModel;


    private View view;

    private ListView mListView;

    private TeamSquad teamSquad = null;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {


        return inflater.inflate(R.layout.fragment_myteam_,null);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        /*

        this.view = view;
        mListView = (ListView)view.findViewById(R.id.listView_myTeam);

        if(teamSquad == null){
            getTeamSquad();
        }else{

            ArrayList<Squad> squad_list = new ArrayList<>();
        }



        }


        league_title.setText(leagueFullName);

        for (Table t : leagueStanding.getStandings().get(0).getTable()) {
            league_table.add(t);
        }
        //CRush Here
        tableAdapter = new LeagueTableAdapter(getContext(),R.layout.row_table,league_table);
        mListView.setAdapter(tableAdapter);

         */
    }


/*
    private void getTeamSquad(){
        Call<TeamSquad> call = apiHandlerInterface.getTeamSquad(57);
        call.enqueue(new Callback<TeamSquad>() {
            @Override
            public void onResponse(Call<TeamSquad> call, Response<TeamSquad> response) {
                teamSquad = response.body();
            }

            @Override
            public void onFailure(Call<TeamSquad> call, Throwable t) {
                Log.e("in enqueue", "onFailure: " + t.getLocalizedMessage());
            }
        });
        
 */
}