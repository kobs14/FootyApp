package com.example.footyapp.ui.League;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.footyapp.MainActivity;
import com.example.footyapp.R;
import com.example.footyapp.pojos.LeagueStanding;
import com.example.footyapp.pojos.Table;
import com.github.twocoffeesoneteam.glidetovectoryou.GlideToVectorYou;
import com.github.twocoffeesoneteam.glidetovectoryou.GlideToVectorYouListener;
import com.squareup.picasso.Picasso;

import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ArrayList;

public class LeagueTableAdapter extends ArrayAdapter<Table> {

    private static final String TAG = "LeagueListAdapter";
    private Context mContext;
    private int mResource;

    public LeagueTableAdapter(@NonNull Context context, int resource, ArrayList<Table> objects) {
        super(context, resource, objects);
        mContext = context;
        mResource = resource;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        if (convertView == null){
            LayoutInflater inflater = LayoutInflater.from(mContext);
            convertView = inflater.inflate(R.layout.row_table,parent,false);
        }

        try {
            ((TextView) convertView.findViewById(R.id.team_position)).setText(getItem(position).getPosition().toString());
            ((TextView) convertView.findViewById(R.id.team_name)).setText(getItem(position).getTeam().getName());
            ((TextView) convertView.findViewById(R.id.matches_played)).setText(getItem(position).getPlayedGames().toString());
            ((TextView) convertView.findViewById(R.id.matches_won)).setText(getItem(position).getWon().toString());
            ((TextView) convertView.findViewById(R.id.matches_drawn)).setText(getItem(position).getDraw().toString());
            ((TextView) convertView.findViewById(R.id.matches_lost)).setText(getItem(position).getLost().toString());
            ((TextView) convertView.findViewById(R.id.team_points)).setText(getItem(position).getPoints().toString());

            URI uri = new URI(getItem(position).getTeam().getCrestUrl());
            GlideToVectorYou.justLoadImage((MainActivity)(parent.getContext()),android.net.Uri.parse(uri.toString()), (ImageView)convertView.findViewById(R.id.team_crest));
        }
        catch (Exception e){
            Log.e("Adapter","error in adapter");
        }
        return convertView;

    }
}
