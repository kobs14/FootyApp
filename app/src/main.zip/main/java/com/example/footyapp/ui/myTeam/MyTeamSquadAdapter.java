package com.example.footyapp.ui.myTeam;

import android.widget.ArrayAdapter;

import com.example.footyapp.pojos.TeamSquad;

public class MyTeamSquadAdapter {}//extends ArrayAdapter<TeamSquad> {

