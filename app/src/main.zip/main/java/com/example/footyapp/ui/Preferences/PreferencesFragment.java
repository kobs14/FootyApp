package com.example.footyapp.ui.Preferences;

import androidx.lifecycle.ViewModelProviders;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.preference.PreferenceFragment;
import androidx.preference.PreferenceFragmentCompat;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.footyapp.R;

public class PreferencesFragment extends PreferenceFragmentCompat {

    private PreferencesViewModel mViewModel;

    public static PreferencesFragment newInstance() {
        return new PreferencesFragment();
    }


    @Override
    public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {
        setPreferencesFromResource(R.xml.preference, rootKey);
        //addPreferencesFromResource(R.xml.preference);
    }


   @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        //return inflater.inflate(R.layout.fragment_preferences,null);
       return inflater.inflate(R.layout.fragment_preferences, container, false);
    }


}
