package com.example.footyapp;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DatabaseHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "dataBaseManager";

    //Tables names
    public static final String TABLE_MATCH = "match_table";
    public static final String TABLE_TEAM = "team_table";
    public static final String TABLE_H2H = "h2h_table";
    public static final String TABLE_League = "league_table";
    public static final String TABLE_UserInfo = "user_info_table";

    // Common column name
    public static final String COL_ID = "id";
    public static final String COL_Team = "team";
    public static final String COL_Competition = "competition";

    //Match Table - column names
    public static final String COL_city = "city";
    public static final String COL_date = "date";
    public static final String COL_teamA = "teamA";
    public static final String COL_teamB = "teamB";
    public static final String COL_time = "time";
    public static final String COL_stadium = "stadium";

    //Team Table - column names
    public static final String COL_firstName = "firstName";
    public static final String COL_secondName = "secondName";
    public static final String COL_age = "age";
    public static final String COL_shirtN = "shirtNumber";
    public static final String COL_goals = "goals";
    /*-----optional----*/
    //public static final String COL_appearanceNumber = "appearanceNumber";


    //H2H-(head to head) Table - column names
    //public static final String COL_Team = "team";
    public static final String COL_game1 = "game1";
    public static final String COL_game2 = "game2";
    public static final String COL_game3 = "game3";
    public static final String COL_game4 = "game4";

    //League Table - column names
    //public static final String COL_Team = "team";
    public static final String COL_Position = "position";
    //public static final String COL_Team = "team";
    public static final String COL_Points = "points";
    public static final String COL_Played = "played";
    public static final String COL_Wins = "wins";
    public static final String COL_Draws = "draws";
    public static final String COL_Losses = "losses";

    // Table Create Statements

    // Match table create statement
    private static final String CREATE_TABLE_MATCH =
            "CREATE TABLE " + DatabaseHelper.TABLE_MATCH + " (" +
                    DatabaseHelper.COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                    DatabaseHelper.COL_date + " TEXT," +
                    DatabaseHelper.COL_teamA + " TEXT," +
                    DatabaseHelper.COL_teamB + " TEXT," +
                    DatabaseHelper.COL_city + " TEXT," +
                    DatabaseHelper.COL_time + " TEXT," +
                    DatabaseHelper.COL_stadium + " TEXT)";

    //Team table create statement
    private static final String CREATE_TABLE_TEAM =
            "CREATE TABLE " + DatabaseHelper.TABLE_TEAM + " (" +
                    DatabaseHelper.COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                    DatabaseHelper.COL_firstName+ " TEXT," +
                    DatabaseHelper.COL_secondName + " TEXT," +
                    DatabaseHelper.COL_age + " INTEGER," +
                    DatabaseHelper.COL_shirtN + " INTEGER," +
                    DatabaseHelper.COL_goals + " INTEGER)";
                   // DatabaseHelper.COL_appearanceNumber + " TEXT)";

    //H2H table create statement
    private static final String CREATE_TABLE_H2H =
            "CREATE TABLE " + DatabaseHelper.TABLE_H2H + " (" +
                    DatabaseHelper.COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                    DatabaseHelper.COL_Team+ " TEXT," +
                    DatabaseHelper. COL_game1 + " TEXT," +
                    DatabaseHelper.COL_game2 + " TEXT," +
                    DatabaseHelper.COL_game3 + " TEXT," +
                    DatabaseHelper.COL_game4 + " TEXT)";

    //League table create statement
    private static final String CREATE_TABLE_League =
            "CREATE TABLE " + DatabaseHelper.TABLE_League + " (" +
                    DatabaseHelper.COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                    DatabaseHelper.COL_Position + " INTEGER," +
                    DatabaseHelper.COL_Team+ " TEXT," +
                    DatabaseHelper.COL_Points + " INTEGER," +
                    DatabaseHelper.COL_Wins + " INTEGER," +
                    DatabaseHelper.COL_Draws + " INTEGER," +
                    DatabaseHelper.COL_Losses + " INTEGER)";


    private static final String CREATE_TABLE_UserInfo =
            "CREATE TABLE " + DatabaseHelper.TABLE_UserInfo + " (" +
            DatabaseHelper.COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
            DatabaseHelper.COL_Competition + " TEXT," +
            DatabaseHelper.COL_Team+ " TEXT)";


    public DatabaseHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, 1);

    }

    @Override
    public void onCreate(SQLiteDatabase db) {
    /*    db.execSQL(CREATE_TABLE_MATCH);
        db.execSQL(CREATE_TABLE_TEAM);
        db.execSQL(CREATE_TABLE_H2H);

     */
        db.execSQL(CREATE_TABLE_UserInfo);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    /*
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_MATCH);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_TEAM);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_H2H);
     */
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_UserInfo);
    }


    /********************************************/
    /*  ------------------------------------    */
    /*  ----Below code need to be fixed-----    */
    /*      -- Adjust to 4 tables!!!--          */
    /********************************************/

    public boolean insertData(String city,String date,String teamA,String teamB,String time, String stadium){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv  = new ContentValues();
        cv.put(COL_date,date);
        cv.put(COL_teamA,teamA);
        cv.put(COL_teamB,teamB);
        cv.put(COL_city,city);
        cv.put(COL_time,time);
        cv.put(COL_stadium, stadium);
        if (db.insert(TABLE_MATCH,null,cv) == -1)
            return false;
        return true;
    }


    /*save user choices for favorite competition and team*/
    /* data is saved in TABLE_UserInfo */
    public boolean inserUserChoise(String competition, String team){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv  = new ContentValues();
        cv.put(COL_Competition,competition);
        cv.put(COL_Team,team);
        if (db.insert(TABLE_UserInfo,null,cv) == -1)
            return false;
        return true;
    }

    /*

    public boolean insertDataLeagueTable(List<Table> list_tabls){

    }

     */

    public Cursor getUserInfo()
    {
        String query = "select * from "+TABLE_UserInfo;
        SQLiteDatabase db = this.getReadableDatabase();//<------Crushs here!!!!
        Cursor res = db.rawQuery(query,null);
        return res;
    }

    public Cursor getUserTeam()
    {
        String query = "select * from "+TABLE_UserInfo;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery(query,null);
        return res;
    }


    public Cursor getByDate(String date)
    {
        String query = "select * from "+TABLE_MATCH+" WHERE "+COL_date+" like  '%"+date+"%'";
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery(query,null);
        return res;
    }

    public Cursor getByTeamA(String team)
    {
        String query = "select * from "+TABLE_MATCH+" WHERE "+COL_teamA+" like  '%"+team+"%'";
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery(query,null);
        return res;
    }
    public Cursor getByTeamB(String team)
    {
        String query = "select * from "+TABLE_MATCH+" WHERE "+COL_teamB+" like  '%"+team+"%'";
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery(query,null);
        return res;
    }



    public Cursor getAllData()
    {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery("select * from " + TABLE_MATCH,null);
        return res;
    }


    public boolean updateData(String id,String city,String date,String teamA,String teamB,String time, String stadium){ //id is the changed match of the game so inorder to change it we need uneiuqe id for every match!
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv  = new ContentValues();
        cv.put(COL_ID,id);
        cv.put(COL_city,city);
        cv.put(COL_date,date);
        cv.put(COL_teamA,teamA);
        cv.put(COL_teamB,teamB);
        cv.put(COL_time,time);
        cv.put(COL_stadium, stadium);
        if ( db.update(TABLE_MATCH,cv,"id = ?",new String[]{id}) > 0)
            return true;
        return false;
    }

    public Integer deleteData(String id){  //we only need id to delete
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_MATCH,"id = ?",new String[] {id});
    }

    public Integer deleteTABLE_UserInfo(String id){
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_UserInfo,"id = ?",new String[] {id});
    }

}