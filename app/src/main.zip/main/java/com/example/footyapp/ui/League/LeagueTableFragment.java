package com.example.footyapp.ui.League;

import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.footyapp.ApiClient;
import com.example.footyapp.ApiHandlerInterface;
import com.example.footyapp.DatabaseHelper;
import com.example.footyapp.MainActivity;
import com.example.footyapp.R;
import com.example.footyapp.pojos.LeagueStanding;
import com.example.footyapp.pojos.Table;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link LeagueTableFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link LeagueTableFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class LeagueTableFragment extends Fragment {

    private String leagueFilter;

    private View view;

    private ListView mListView;
    private TextView league_title;
    private LeagueTableAdapter tableAdapter;
    private ApiHandlerInterface apiHandlerInterface;
    private static LeagueStanding leagueStanding = null;
    private ArrayList<Table> league_table = new ArrayList<>();


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setRetainInstance(true);

        DatabaseHelper db = new DatabaseHelper(getActivity());
        apiHandlerInterface = ApiClient.getClient().create(ApiHandlerInterface.class);
        ArrayList<Table> tableArrayList = new ArrayList<>();


        Cursor s = db.getUserInfo();
        s.moveToLast();
        String leagueName = s.getString(1);

        if (leagueStanding == null) {
            getLeagueStanding(leagueName);
        }


    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.league_table, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        //leagueListView = (ListView)findViewById(R.id.listView_league);
        this.view = view;
        mListView = (ListView)view.findViewById(R.id.listView_league_table);




        if (leagueStanding != null) {

            String leagueFullName = leagueStanding.getCompetition().getName();

            league_title = (TextView)getActivity().findViewById(R.id.league_tbl_title);
    /*        switch (leagueStanding.getCompetition().) {
                case "PL":
                    leagueFullName = "Premier League";
                    break;
                case "FL1":
                    leagueFullName = "Ligue 1";
                    break;

                case "SA":
                    leagueFullName = "Série A";
                    break;

                case "BL1":
                    leagueFullName = "Bundesliga";
                    break;
                case "PD":
                    leagueFullName = "Primera División";
                    break;
            }

     */
            league_title.setText(leagueFullName);

            for (Table t : leagueStanding.getStandings().get(0).getTable()) {
                league_table.add(t);
            }
            //CRush Here
            tableAdapter = new LeagueTableAdapter(getContext(),R.layout.row_table,league_table);
            mListView.setAdapter(tableAdapter);
        }
    }



    private void getLeagueStanding(String league_filter){
        Call<LeagueStanding> call = apiHandlerInterface.getLeagueStanding(league_filter);
        call.enqueue(new Callback<LeagueStanding>() {
            @Override
            public void onResponse(Call<LeagueStanding> call, Response<LeagueStanding> response) {
                leagueStanding = response.body();
            }

            @Override
            public void onFailure(Call<LeagueStanding> call, Throwable t) {
                Log.e("in enqueue", "onFailure: " + t.getLocalizedMessage());
            }
        });

    }

    private void drawTable(){

        try {
            mListView = (ListView)view.findViewById(R.id.listView_league_table);
            if (leagueStanding != null) {
                for (Table t : leagueStanding.getStandings().get(0).getTable()) {
                    league_table.add(t);
                }
            }else{
                Toast.makeText(getActivity(),"LeagueStanding is NULL!",Toast.LENGTH_SHORT).show();
            }
            tableAdapter = new LeagueTableAdapter(getActivity(),R.layout.row_table,league_table);
            mListView.setAdapter(tableAdapter);
        }
        catch (Exception e){
            Log.e("in enqueue", "in drawTable " + e.getMessage());
        }


    }


}
