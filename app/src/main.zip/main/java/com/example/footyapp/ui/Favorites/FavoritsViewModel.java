package com.example.footyapp.ui.Favorites;

import androidx.lifecycle.ViewModel;

public class FavoritsViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
