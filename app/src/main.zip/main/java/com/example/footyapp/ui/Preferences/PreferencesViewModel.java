package com.example.footyapp.ui.Preferences;

import androidx.lifecycle.ViewModel;

public class PreferencesViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
