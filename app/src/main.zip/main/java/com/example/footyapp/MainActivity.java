package com.example.footyapp;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import android.widget.VideoView;

import com.example.footyapp.pojos.LeagueStanding;
import com.example.footyapp.pojos.TeamsOfLeague;
import com.example.footyapp.ui.Favorites.FavoritsFragment;
import com.example.footyapp.ui.League.LeagueTableFragment;
import com.example.footyapp.ui.Preferences.PreferencesFragment;
import com.example.footyapp.ui.matches.MatchesFragment;
import com.example.footyapp.ui.myTeam.MyTeamFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
public class MainActivity extends AppCompatActivity implements BottomNavigationView.OnNavigationItemSelectedListener{


    DatabaseHelper dbHelper;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DatabaseHelper(this);

        Intent intent = new Intent(MainActivity.this,SittingsActivity.class);
        startActivity(intent);

        //getting bottom navigation view and attaching the listener
        BottomNavigationView navigation = findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(this);

    }


    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        Fragment fragment = null;

        switch (menuItem.getItemId()) {
            case R.id.navigation_matches:
                fragment = new MatchesFragment();
                break;

            case R.id.navigation_league:
                fragment = new LeagueTableFragment();
                break;

            case R.id.navigation_myteam:
                fragment = new MyTeamFragment();
                break;

            case R.id.navigation_favorites:
                fragment = new FavoritsFragment();
                break;

            case R.id.navigation_preferences:
                fragment = new PreferencesFragment();
                break;
        }

        return loadFragment(fragment);
    }

    private boolean loadFragment(Fragment fragment) {
        //switching fragment
        if (fragment != null) {
            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.nav_host_fragment, fragment)
                    .commit();
            return true;
        }
        return false;
    }

    /*

    private void getLeagueStanding(String league_filter){
        leagueStanding = null;
        Call<LeagueStanding> call = apiHandlerInterface.getLeagueStanding(league_filter);
        call.enqueue(new Callback<LeagueStanding>() {
            @Override
            public void onResponse(Call<LeagueStanding> call, Response<LeagueStanding> response) {
                leagueStanding = response.body();
                Log.e("in enqueue", "onREspone: " + response.body());

            }

            @Override
            public void onFailure(Call<LeagueStanding> call, Throwable t) {
                Log.e("in enqueue", "onFailure: " + t.getLocalizedMessage());
            }
        });

    }

     */



}
