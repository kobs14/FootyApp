package com.example.footyapp;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.example.footyapp.pojos.LeagueStanding;
import com.example.footyapp.pojos.Team;
import com.example.footyapp.pojos.TeamsOfLeague;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SittingsActivity extends AppCompatActivity {

    DatabaseHelper dbHelper;

    ApiHandlerInterface apiHandlerInterface;
    Button submitBtnn;
    String LeagueSelectede = null;
    String TeamSelected = null;

    private Context mContext= this;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.sitting_activity);

        dbHelper = new DatabaseHelper(this);
        apiHandlerInterface = ApiClient.getClient().create(ApiHandlerInterface.class);
        CreatLeagueSpinner();
        //Spinner teams_Spinner = CreateTeamsSpinner(null);

        submitBtnn = (Button)findViewById(R.id.submitBtn);

        submitBtnn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (LeagueSelectede != null && TeamSelected != null && LeagueSelectede != "None" && TeamSelected != "None") {

                    getLeagueStanding(LeagueSelectede);
                   if (dbHelper.inserUserChoise(LeagueSelectede,TeamSelected)){
                       finish();
                   }else {
                       Toast.makeText(mContext,"Faild to insert data.",Toast.LENGTH_SHORT).show();
                   }
                }
            }
        });



    }
    public void CreatLeagueSpinner(){
        Spinner league_spinner = (Spinner)findViewById(R.id.spinner_league);
        league_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String LeagueAddChoise = parent
                        .getItemAtPosition(position).toString();
                CreateTeamsSpinner(LeagueAddChoise);

            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }


    public void CreateTeamsSpinner (String chosenLeague){

        String[] LeagueNamesArray = getResources().getStringArray(
                R.array.league_names);

        switch (chosenLeague){

            case "Premier League":
                sendNetworkRequestTeamsList("PL");
                LeagueSelectede = "PL";
                break;
            case "Ligue 1":
                sendNetworkRequestTeamsList("FL1");
                LeagueSelectede = "FL1";
                break;

            case "Série A":
                sendNetworkRequestTeamsList("SA");
                LeagueSelectede = "SA";
                break;

            case "Bundesliga":
                sendNetworkRequestTeamsList("BL1");
                LeagueSelectede = "BL1";
                break;
            case "Primera División":
                sendNetworkRequestTeamsList("PD");
                LeagueSelectede = "PD";
                break;
            case "None":
                break;
        }


    }


    public void AdjustTeamsSpinner(TeamsOfLeague teamsOfLeague){

        ArrayList<String> teams_list = new ArrayList<>();
        Spinner spinner = (Spinner) findViewById(R.id.spinner_teams);
        teams_list.add("None");
        for (Team t : teamsOfLeague.getTeams()) {
            teams_list.add(t.getName());
        }

        final ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>(this,R.layout.spinner_item,teams_list);
        spinnerArrayAdapter.setDropDownViewResource(R.layout.spinner_item);
        spinner.setAdapter(spinnerArrayAdapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                TeamSelected = parent
                        .getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
        spinnerArrayAdapter.notifyDataSetChanged();

    }

    private void sendNetworkRequestTeamsList(String league_filter){
        getTeams(league_filter);
    }



    //Api Calls

    private void getTeams(String league_name) {
        Call<TeamsOfLeague> call = apiHandlerInterface.getTeamsOfLeague(league_name);
        call.enqueue(new Callback<TeamsOfLeague>() {
            @Override
            public void onResponse(Call<TeamsOfLeague> call, Response<TeamsOfLeague> response) {
                Log.e("in enqueue", "onREspone: " + response.body());
                TeamsOfLeague resultTeams = response.body();
                AdjustTeamsSpinner(resultTeams);
            }


            @Override
            public void onFailure(Call<TeamsOfLeague> call, Throwable t) {
                Log.e("in enqueue", "onFailure: " + t.getLocalizedMessage());

            }
        });
    }




    private void getLeagueStanding(String league_name){
        Call<LeagueStanding> call = apiHandlerInterface.getLeagueStanding(league_name);
        call.enqueue(new Callback<LeagueStanding>() {
            @Override
            public void onResponse(Call<LeagueStanding> call, Response<LeagueStanding> response) {
                Log.e("in enqueue", "onREspone: " + response.body());

            }

            @Override
            public void onFailure(Call<LeagueStanding> call, Throwable t) {
                Log.e("in enqueue", "onFailure: " + t.getLocalizedMessage());
            }
        });


    }


    private boolean loadDefaultFragment(Fragment fragment) {
        //switching fragment
        if (fragment != null) {
            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.nav_host_fragment, fragment)
                    .commit();
            return true;
        }
        return false;
    }


}
