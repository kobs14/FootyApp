package com.example.footyapp;

import com.example.footyapp.pojos.LeagueStanding;
import com.example.footyapp.pojos.TeamSquad;
import com.example.footyapp.pojos.TeamsOfLeague;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Headers;
import retrofit2.http.Path;

public interface ApiHandlerInterface {

    @Headers("X-Auth-Token: 7cb45770c8794bdf82b00c120660a2ff")
    @GET("competitions/{name}/teams")
    Call<TeamsOfLeague> getTeamsOfLeague(@Path("name") String name);

    @Headers("X-Auth-Token: 7cb45770c8794bdf82b00c120660a2ff")
    @GET("competitions/{name}/standings")
    Call<LeagueStanding> getLeagueStanding(@Path("name") String name);

    @Headers("X-Auth-Token: 7cb45770c8794bdf82b00c120660a2ff")
    @GET("teams/{id}")
    Call<TeamSquad> getTeamSquad(@Path("id") int id);
}
