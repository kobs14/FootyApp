
package com.example.footyapp.pojos;


public class Filters {


}
